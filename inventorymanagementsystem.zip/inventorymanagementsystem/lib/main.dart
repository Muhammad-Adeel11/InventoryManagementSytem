import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(InventoryApp());
}

class InventoryApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Inventory System',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: ItemListPage(),
    );
  }
}

class ItemListPage extends StatefulWidget {
  @override
  _ItemListPageState createState() => _ItemListPageState();
}

class _ItemListPageState extends State<ItemListPage> {
  final CollectionReference items =
      FirebaseFirestore.instance.collection('items');

  void _showItemForm([DocumentSnapshot? doc]) {
    final nameController =
        TextEditingController(text: doc != null ? doc['name'] : '');
    final categoryController =
        TextEditingController(text: doc != null ? doc['category'] : '');
    final quantityController = TextEditingController(
        text: doc != null ? doc['quantity'].toString() : '');
    final priceController = TextEditingController(
        text: doc != null ? doc['price'].toString() : '');

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(doc != null ? 'Update Item' : 'Add Item'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                  controller: nameController,
                  decoration: InputDecoration(labelText: 'Item Name')),
              TextField(
                  controller: categoryController,
                  decoration: InputDecoration(labelText: 'Category')),
              TextField(
                  controller: quantityController,
                  decoration: InputDecoration(labelText: 'Quantity'),
                  keyboardType: TextInputType.number),
              TextField(
                  controller: priceController,
                  decoration: InputDecoration(labelText: 'Price'),
                  keyboardType: TextInputType.number),
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            child: Text(doc != null ? 'Update' : 'Add'),
            onPressed: () {
              final name = nameController.text;
              final category = categoryController.text;
              final quantity = int.tryParse(quantityController.text) ?? 0;
              final price = double.tryParse(priceController.text) ?? 0;

              if (name.isNotEmpty &&
                  category.isNotEmpty &&
                  quantity >= 0 &&
                  price >= 0) {
                if (doc != null) {
                  items.doc(doc.id).update({
                    'name': name,
                    'category': category,
                    'quantity': quantity,
                    'price': price
                  });
                } else {
                  items.add({
                    'name': name,
                    'category': category,
                    'quantity': quantity,
                    'price': price
                  });
                }
                Navigator.pop(context);
              }
            },
          )
        ],
      ),
    );
  }

  void _deleteItem(String id) {
    items.doc(id).delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Inventory Items')),
      body: StreamBuilder(
        stream: items.snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData)
            return Center(child: CircularProgressIndicator());

          return ListView(
            children: snapshot.data!.docs.map((doc) {
              final data = doc.data() as Map<String, dynamic>;
              return ListTile(
                title: Text(data['name']),
                subtitle: Text(
                    'Category: ${data['category']}, Qty: ${data['quantity']}, Price: \$${data['price']}'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                        icon: Icon(Icons.edit),
                        onPressed: () => _showItemForm(doc)),
                    IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () => _deleteItem(doc.id)),
                  ],
                ),
              );
            }).toList(),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showItemForm(),
        child: Icon(Icons.add),
      ),
    );
  }
}
