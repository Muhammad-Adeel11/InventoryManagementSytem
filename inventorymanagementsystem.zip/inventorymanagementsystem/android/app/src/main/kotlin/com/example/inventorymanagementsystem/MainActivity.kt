package com.example.inventorymanagementsystem

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
